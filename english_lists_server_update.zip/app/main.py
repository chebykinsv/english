import os
import base64
import re
import time
import secrets
import sqlite3
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from urllib.parse import urlsplit

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from starlette.middleware.sessions import SessionMiddleware

os.umask(0o077)
DB_PATH = "/data/english.db"
ADMIN_USERNAME = os.environ["ADMIN_USERNAME"]
ADMIN_PASSWORD_HASH = base64.b64decode(os.environ["ADMIN_PASSWORD_HASH"]).decode("utf-8")
SESSION_SECRET = os.environ["SESSION_SECRET"]

hasher = PasswordHasher()
login_attempts = defaultdict(deque)


def get_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


@asynccontextmanager
async def lifespan(app: FastAPI):
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS favorites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phrase TEXT NOT NULL,
                translation TEXT NOT NULL,
                lesson_title TEXT NOT NULL,
                lesson_url TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(phrase, translation, lesson_url)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS favorite_lists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner TEXT NOT NULL,
                name TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS favorite_list_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                list_id INTEGER NOT NULL REFERENCES favorite_lists(id) ON DELETE CASCADE,
                position INTEGER NOT NULL,
                phrase TEXT NOT NULL,
                translation TEXT NOT NULL,
                lesson_title TEXT NOT NULL,
                lesson_url TEXT NOT NULL
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_favorite_lists_owner ON favorite_lists(owner)")
        db.execute("PRAGMA foreign_keys = ON")
        db.commit()
    yield


app = FastAPI(title="English Personal API", docs_url=None, redoc_url=None,
              openapi_url=None, lifespan=lifespan)

app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    session_cookie="english_session",
    max_age=60 * 60 * 24 * 30,
    same_site="strict",
    https_only=True,
    path="/",
)


class LoginData(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class FavoriteData(BaseModel):
    phrase: str = Field(min_length=1, max_length=1000)
    translation: str = Field(min_length=1, max_length=1000)
    lesson_title: str = Field(min_length=1, max_length=200)
    lesson_url: str = Field(min_length=1, max_length=500)



class FavoriteListItem(BaseModel):
    phrase: str = Field(min_length=1, max_length=1000)
    translation: str = Field(min_length=1, max_length=1000)
    lesson_title: str = Field(default="Импортированный список", max_length=200)
    lesson_url: str = Field(default="/", max_length=500)


class FavoriteListCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    items: list[FavoriteListItem] = Field(default_factory=list, max_length=5000)


class FavoriteListRename(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class FavoriteListsImport(BaseModel):
    lists: list[FavoriteListCreate] = Field(max_length=500)


def check_origin(request: Request):
    origin = request.headers.get("origin")
    host = request.headers.get("host", "").lower()

    if not origin or not host:
        raise HTTPException(status_code=403, detail="Invalid origin")

    parsed = urlsplit(origin)
    if parsed.scheme != "https" or parsed.netloc.lower() != host:
        raise HTTPException(status_code=403, detail="Invalid origin")


def require_auth(request: Request):
    if request.session.get("user") != ADMIN_USERNAME:
        raise HTTPException(status_code=401, detail="Authentication required")


def require_csrf(request: Request):
    require_auth(request)
    supplied = request.headers.get("x-csrf-token", "")
    expected = request.session.get("csrf", "")

    if not expected or not secrets.compare_digest(supplied, expected):
        raise HTTPException(status_code=403, detail="Invalid CSRF token")


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/auth/csrf")
def get_csrf(request: Request):
    token = secrets.token_urlsafe(32)
    request.session["csrf"] = token
    return {"csrf_token": token}


@app.post("/api/auth/login")
def login(data: LoginData, request: Request):
    check_origin(request)

    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    attempts = login_attempts[client_ip]

    while attempts and now - attempts[0] > 900:
        attempts.popleft()

    if len(attempts) >= 5:
        raise HTTPException(status_code=429, detail="Too many attempts")

    attempts.append(now)

    valid = data.username == ADMIN_USERNAME
    try:
        valid = valid and hasher.verify(ADMIN_PASSWORD_HASH, data.password)
    except (VerifyMismatchError, VerificationError, ValueError):
        valid = False

    if not valid:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    attempts.clear()
    request.session.clear()
    request.session["user"] = ADMIN_USERNAME
    request.session["csrf"] = secrets.token_urlsafe(32)

    return {"ok": True, "username": ADMIN_USERNAME,
            "csrf_token": request.session["csrf"]}


@app.post("/api/auth/logout")
def logout(request: Request):
    require_csrf(request)
    request.session.clear()
    response = JSONResponse({"ok": True})
    response.delete_cookie("english_session", path="/", secure=True,
                           httponly=True, samesite="strict")
    return response


@app.get("/api/auth/me")
def me(request: Request):
    require_auth(request)
    return {"authenticated": True, "username": ADMIN_USERNAME}


@app.get("/api/favorites")
def list_favorites(request: Request):
    require_auth(request)
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM favorites ORDER BY created_at DESC"
        ).fetchall()
    return {"favorites": [dict(row) for row in rows]}


@app.post("/api/favorites")
def add_favorite(data: FavoriteData, request: Request):
    require_csrf(request)

    if not data.lesson_url.startswith("/") or data.lesson_url.startswith("//"):
        raise HTTPException(status_code=400, detail="Invalid lesson URL")

    with get_db() as db:
        db.execute("""
            INSERT OR IGNORE INTO favorites
            (phrase, translation, lesson_title, lesson_url, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            data.phrase.strip(),
            data.translation.strip(),
            data.lesson_title.strip(),
            data.lesson_url,
            datetime.now(timezone.utc).isoformat()
        ))
        db.commit()

    return {"ok": True}


@app.delete("/api/favorites/{favorite_id}")
def delete_favorite(favorite_id: int, request: Request):
    require_csrf(request)

    with get_db() as db:
        db.execute("DELETE FROM favorites WHERE id = ?", (favorite_id,))
        db.commit()

    return {"ok": True}
